import os
import cv2 as cv

# Проверяем существование файла
picture_files_path = './jpg/'
file1 = picture_files_path + 'dict__.jpg'


dict_img = cv.imread(file1)
    
if dict_img is None:
    print("Ошибка загрузки изображения")
else:
    print(f"Изображение загружено успешно. Размер: {dict_img.shape}")
    cv.imshow('image', dict_img)
    cv.waitKey(0)
    cv.destroyAllWindows()


blurred = cv.GaussianBlur(dict_img, (5, 5), 0)
cv.imshow('blur', blurred)
cv.waitKey(0)
cv.destroyAllWindows()
